#!/bin/sh

rm /go.mod /main.go